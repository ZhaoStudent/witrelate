"""本地自检 —— 不联网、不注册、不需要凭据。

这是你拿到平台凭据之前唯一该做的事：把能离线验证的全部验证掉。
跑通这个脚本，说明 Agent 定义、ACS 契约、工具接线都是对的，
之后注册失败就只剩"平台侧"的原因，排查范围一下缩小一半。

用法（在 witrelate 目录下）：
    ./.venv/bin/python -m legal_acps.check_local
"""

from __future__ import annotations

import asyncio
import importlib
import json
import re
import shutil
import subprocess
from pathlib import Path
from typing import NamedTuple

from wit import AcpsDirect, AcpsGroup, AipDelegationHooks, WitRuntime

from dotenv_lite import load_env

from .agents import (
    BUILDERS,
    EVIDENCE_LEADER_INSTRUCTIONS,
    FACT_JUDGE_INSTRUCTIONS,
    LEADER_INSTRUCTIONS,
    build_agent,
)
from .contracts import (
    DEBATE_MAX_ROUNDS,
    FALLACY_EVIDENCE_KINDS,
    FALLACY_RHETORIC_KINDS,
    HARM_BAND_TABLE,
    MAX_CHAIN_DEPTH,
    ArbitrationCase,
    EvidenceCase,
    EvidenceModality,
    EvidenceRuling,
    FactRuling,
    FallacyKind,
    band_of,
    fallacy_layer,
)
from .debate import (
    DebateChainError,
    DebateChainGuardHooks,
    account_prefix_of,
    plan_next_hop,
    should_terminate,
)
from .acps_config import DEPLOY_ROLES, PORTS, SOFT_RETIRED, build_config, describe
from .evidence.inbox import MAX_STAGE_BYTES
from .evidence_hooks import KIND_PROFILES
from .termination import LeaderTerminationHooks
from .video_modality import VIDEO_CAPABLE_ROLES

# 一个不联网的假模型，只为实现编译期接线检查
DUMMY_MODEL = None


#: 每个模态的「取用方上限」住在自己的 fetch 模块里。
#: ⚠️ 图像链最早落地，它的包名是 `evidence`（**不是** `image`）—— 这不是笔误；
#: 音频 / 视频各自的包名与 `kind` 同名。
#: 这张表只是**定位器**，不是事实本身：上限值每次都从模块里现读，并且下面会整表
#: 断言"每个模态都登记了模块"，所以将来加模态时**不会静默跳过**这条不变量。
_FETCH_MODULE_BY_KIND: dict[str, str] = {
    "image": "legal_acps.evidence.fetch",
    "audio": "legal_acps.audio.fetch",
    "video": "legal_acps.video.fetch",
}


class ModalityRow(NamedTuple):
    """一个模态**从枚举现场派生**出来的四处接线。"""

    modality: EvidenceModality
    role: str                    # 角色 id（约定：`evidence-<kind>`）
    agent: object | None         # 建不起来就是 None —— 不抛异常，交给断言去报
    partner_name: str            # Partner **自己注册的名字**（Leader 必须照这个名字找）
    inbox_kinds: tuple[str, ...]  # 本角色收件箱收哪些模态


def _modality_rows() -> list[ModalityRow]:
    """现场派生「模态 → 角色 id / 角色对象 / 下游名字 / 收件箱 kinds」。

    为什么**派生**而不是手抄清单：同一个事实在本项目里散成四处，手抄的每一份
    都是下一个会漂的副本 —— 而且漂的时候**每一处看起来都是对的**：

        `EvidenceModality`（模型看到的中文，也是提示词里分支标签的原料）
        `evidence-<kind>`（角色 id，见 `EvidenceModality.kind` 的 docstring）
        Partner 的 `display_name`（Leader 被交代的下游名字）
        `EvidenceInboxHooks(kinds=…)`（收件箱要收哪些模态）

    ⚠️ 角色建不起来（`BUILDERS` 里没有）时返回 `agent=None` 而不是抛 `KeyError`：
    看板的职责是**把结构问题报出来**，一次 traceback 只告诉人"脚本坏了"，
    不告诉人"少了哪个角色"，而且它会发生在后续检查之前，整份看板只留一行栈。
    """
    rows: list[ModalityRow] = []
    for m in EvidenceModality:
        role = f"evidence-{m.kind}"
        builder = BUILDERS.get(role)
        agent = builder(DUMMY_MODEL) if builder is not None else None
        hooks = {getattr(h, "id", ""): h for h in getattr(agent, "hooks", [])}
        inbox = hooks.get("legal.evidence-inbox")
        rows.append(
            ModalityRow(
                modality=m,
                role=role,
                agent=agent,
                partner_name=str(getattr(agent, "display_name", "") or ""),
                inbox_kinds=tuple(getattr(inbox, "kinds", ()) or ()),
            )
        )
    return rows


def _quote(name: str) -> str:
    """把名字包成「」，只为失败信息好读。"""
    return f"「{name}」"


def _hook_ids_of(agent: object | None) -> set[str]:
    return {getattr(h, "id", "") for h in getattr(agent, "hooks", [])}


def _inbox_kinds_of(agent: object | None) -> tuple[str, ...]:
    for h in getattr(agent, "hooks", []):
        if getattr(h, "id", "") == "legal.evidence-inbox":
            return tuple(getattr(h, "kinds", ()) or ())
    return ()


def _role_agents() -> dict[str, object]:
    """把 10 个角色各建一次（离线假模型）。看板要多处用，只建一遍。"""
    return {role: BUILDERS[role](DUMMY_MODEL) for role in BUILDERS}


def _mib(n: int) -> int:
    """字节 → MiB（向下取整），只为失败 / 通过信息好读 —— 不参与任何判据。"""
    return n // (1024 * 1024)


def _modality_partner_names() -> list[str]:
    """Leader 应当被交代的下游名字 —— 取自 Partner **自己注册的** `display_name`。"""
    return [r.partner_name for r in _modality_rows()]


def _leader_leaked_partner_names() -> list[str]:
    """主控提示词里**不该出现**的下游注册名，实际出现了哪些。

    判据是"两边的名字一致"，不是"我抄对了没"：清单来自各 Partner 自己注册的
    `display_name`，所以 Partner 改名而提示词没跟上时这里也会响。
    ⚠️ 空名字要**排除掉**再比：`"" in text` 恒为真，一条空名字会让这条断言
    **静默通过** —— 那正好是最需要它响的时候。
    """
    return sorted(
        r.partner_name
        for r in _modality_rows()
        if r.partner_name and r.partner_name in LEADER_INSTRUCTIONS
    )


def _leader_missing_branches() -> list[str]:
    """主控提示词里**应当有**却缺失的鉴伪分支标签。

    约定 `f"{模态}鉴伪分支"` —— 与 Partner 名共用同一套词（`图像` / `音频` / `视频`），
    所以加一个模态时正反两条判据会一起跟上，不必手改清单。
    """
    labels = [f"{m.value}鉴伪分支" for m in EvidenceModality]
    return [lbl for lbl in labels if lbl not in LEADER_INSTRUCTIONS]


def section(title: str) -> None:
    print()
    print("=" * 68)
    print(title)
    print("=" * 68)


def check_contracts() -> bool:
    section("1. 评分量表自检")
    ok = True
    # 分档必须完整覆盖 -100..100 且不重叠
    covered: set[int] = set()
    for lo, hi, band, _ in HARM_BAND_TABLE:
        for v in range(lo, hi + 1):
            if v in covered:
                print(f"  [失败] {v} 被多个分档覆盖")
                ok = False
            covered.add(v)
    missing = sorted(set(range(-100, 101)) - covered)
    if missing:
        print(f"  [失败] 未覆盖的分值：{missing[:10]}")
        ok = False
    if ok:
        print("  [通过] 分档完整覆盖 -100..100，无重叠")
    for probe in (-100, -30, 0, 15, 55, 90, 100):
        print(f"    harm_index={probe:>4}  ->  {band_of(probe).value}")
    return ok


def check_nesting() -> bool:
    """嵌套结构的契约与拓扑自检（2026-09-29 改造后新增）。

    这一节防的是「结构被悄悄改回去」。两条最容易退化的性质：
      · 裁判必须**独立存在**，而不是又让辩手兼任 —— 兼任就是既当运动员又当裁判；
      · 正方不得重新长出委派能力，否则它会再次变成子会话 Leader。

    另外校验误导性话术齐全（两层：证据层 4 + 修辞层 6）—— 它们是"反诈辨识"的原料，
    缺一类就少一课；而**没归层**的话术会被前端分组悄悄丢掉，同样算缺陷。
    """
    section("2c. 嵌套结构自检（主控 → 网络裁判 → 正/反方）")
    ok = True

    # ① 角色齐备、端口唯一
    # 这里是**刻意写死的快照**，不是"又一处会漂移的副本"：
    # 2c 要回答的是"结构是不是我们**打算要的样子**"，所以它必须是一份独立的主张，
    # 不能从 BUILDERS 派生（那就永远自洽、也就永远查不出问题）。
    # 与脚本清单保持一致由 3b 负责（那条是"必须相等"，所以必须派生）。
    expected_roles = {
        # ⚠️ 这两个自 2026-10-02 起**软废弃**：不部署、不进主控链路，
        #    但**仍在 BUILDERS 里**（代码保留 + 平台注册保留 ⇒ 重新启用不必重走审核）。
        #    "在 BUILDERS 里" ≠ "要部署" —— 部署清单是 DEPLOY_ROLES，由下面单独断言。
        "incitement",
        "harm",
        "leader",
        "fact-judge",
        "debate-pro",
        "debate-con",
        # 2026-09-30 新增：图像鉴伪（纯 Partner，由主控中继调用）。
        # 它是加分项证据鉴证的第一个模态，不属于"主控 → 裁判 → 正/反方"那条链，
        # 所以在下面第 ② 步的链关系里**不参与**（只要求角色齐备 + 端口唯一）。
        "evidence-image",
        # 2026-10-02 新增：证据鉴证 Leader —— 证据链的内层 Leader，
        # 与 `fact-judge` 同形（S1 Partner ＋ S2 Leader）。
        # 主控**只认这一个鉴伪入口**，由它去组织下游的鉴伪专家；
        # 它存在的理由是步数预算（详见 agents.py 里 build_evidence_leader 的注释）。
        "evidence-leader",
        # 2026-10-02 新增：音频鉴伪（证据鉴证的第二个模态）。
        # ⚠️ 它是**加在证据链的第三级上（与 evidence-image 平级）**，
        #    不是加在图像底下 —— 后者会撞 `MAX_CHAIN_DEPTH = 3`。
        #    同理不进第 ② 步的"主控 → 裁判 → 正/反方"链关系。
        "evidence-audio",
        # 2026-10-02 新增：视频鉴伪（证据鉴证的第三个模态）。
        # 同样是**第三级、与图像 / 音频平级**；链深 3/3 已到顶。
        "evidence-video",
    }
    if set(BUILDERS) != expected_roles:
        print(f"  [失败] 角色集合不符：{sorted(BUILDERS)}（后续检查跳过）")
        return False
    print(f"  [通过] {len(BUILDERS)} 个角色齐备：{sorted(BUILDERS)}")

    # ①-补 软废弃的结构主张（2026-10-02）。三件事必须**同时**成立 ——
    #     缺任何一条，"软废弃"就已经漂成别的东西了：
    #       · 软废弃的角色仍在 BUILDERS 里  → 代码没被删，可重新启用；
    #       · 它们不在 DEPLOY_ROLES 里      → 真的没在跑，主控链路已摘净；
    #       · 两者并起来正好等于全部角色     → 没有第三个去向（比如被静默删除）。
    #     少了这条断言，最容易发生的退化是"软废弃慢慢变成彻底删除"——
    #     而现象是**一切全绿**，直到某天想重新启用才发现代码没了。
    soft, deploy, all_roles = set(SOFT_RETIRED), set(DEPLOY_ROLES), set(BUILDERS)
    soft_problems: list[str] = []
    if not soft <= all_roles:
        soft_problems.append(f"不在 BUILDERS 里（代码被删了？）：{sorted(soft - all_roles)}")
    if soft & deploy:
        soft_problems.append(f"仍在部署清单里（没真停？）：{sorted(soft & deploy)}")
    if soft | deploy != all_roles:
        soft_problems.append(
            f"并集 != 全部角色：多出 {sorted((soft | deploy) - all_roles)}、"
            f"漏了 {sorted(all_roles - (soft | deploy))}"
        )
    if soft_problems:
        print(f"  [失败] 软废弃清单不自洽：{'；'.join(soft_problems)}")
        ok = False
    else:
        print(
            f"  [通过] 软废弃 {len(soft)} 个（{sorted(soft)}）：代码保留、不部署，"
            f"与部署清单（{len(deploy)} 个）互补"
        )
    # ⚠️ 先查"有没有登记"，再算"有没有冲突"。直接写 `PORTS[r]` 会在**缺登记**时
    #    抛 `KeyError` —— 而看板的职责恰恰是**把结构问题报出来**：一次 traceback
    #    只告诉人"脚本坏了"，不告诉人"少给哪个角色配了端口"，而且它还发生在
    #    "后续检查"之前，于是整份看板只留下一行栈。
    #    （2026-10-02 元验证用例 7 实测踩到：把 `evidence-audio` 从 PORTS 里去掉，
    #      报出来的不是诊断而是一段 `KeyError` 栈。）
    missing_ports = sorted(r for r in BUILDERS if r not in PORTS)
    if missing_ports:
        print(f"  [失败] 这些角色没有登记端口：{missing_ports}")
        ok = False
    ports = [PORTS[r] for r in BUILDERS if r in PORTS]
    if len(set(ports)) != len(ports):
        print(f"  [失败] 端口冲突：{ports}")
        ok = False
    elif not missing_ports:
        print(f"  [通过] 端口互不冲突：{sorted(ports)}")

    # ② 内层 Leader：裁判必须同时具备「被委托」与「委托」两种能力
    judge_hooks = {getattr(h, "id", ""): h for h in BUILDERS["fact-judge"](DUMMY_MODEL).hooks}
    has_deleg = any(k.startswith("acps.aip.delegation") for k in judge_hooks)
    has_guard = "legal.termination-guard" in judge_hooks
    if has_deleg and has_guard:
        print("  [通过] 网络裁判同时具备「被委托」与「委托」能力 → 内层 Leader 成立")
    else:
        print(
            f"  [失败] 网络裁判职责不全：delegation={has_deleg} termination={has_guard}"
            "（缺任一项，两级嵌套就不成立）"
        )
        ok = False

    guard = judge_hooks.get("legal.termination-guard")
    if guard is not None:
        if getattr(guard, "expected_partners", None) == 2:
            print("  [通过] 裁判等待 2 位下游（正方 + 反方）")
        else:
            print(
                f"  [失败] 裁判预期下游数应为 2，实际 {getattr(guard, 'expected_partners', None)}"
            )
            ok = False

    # ②-补 证据鉴证 Leader（2026-10-02 新增）—— 形态与裁判一致，但**必须有它自己的断言**。
    #
    #   为什么不能只断言"裁判是内层 Leader"就算完：这两个角色的**退化方式不同**。
    #   裁判断链 = "没人组织辩论"，一眼能看出来；而证据链多这一层**是为了省步数预算**
    #   （服务模式 `max_steps=8` 钉死，`RunConfig` frozen）—— 它一旦退化成
    #   "主控又直接对接鉴伪专家"，**不会报任何错**，只是模态一多就装不下、链路悄悄变慢变错。
    ev_hooks = {getattr(h, "id", ""): h for h in BUILDERS["evidence-leader"](DUMMY_MODEL).hooks}
    ev_deleg = any(k.startswith("acps.aip.delegation") for k in ev_hooks)
    ev_guard_id = "legal.termination-guard"
    ev_inbox_id = "legal.evidence-inbox"
    ev_guard = ev_guard_id in ev_hooks
    ev_inbox = ev_inbox_id in ev_hooks
    if ev_deleg and ev_guard and ev_inbox:
        print("  [通过] 证据鉴证 Leader 具备「委托 / 强制交付 / 收件箱」三件能力")
    else:
        print(
            f"  [失败] 证据鉴证 Leader 职责不全：delegation={ev_deleg} "
            f"termination={ev_guard} inbox={ev_inbox}"
        )
        ok = False

    ev_guard_hook = ev_hooks.get(ev_guard_id)
    if ev_guard_hook is not None:
        if getattr(ev_guard_hook, "expected_partners", None) == 1:
            print("  [通过] 证据鉴证 Leader 等待 1 位下游（鉴伪专家）")
        else:
            print(
                "  [失败] 证据鉴证 Leader 预期下游数应为 1，实际 "
                f"{getattr(ev_guard_hook, 'expected_partners', None)}"
                "（`_decide` 的判据是 `max(expected, delegations)`，写大了会永不触发收尾）"
            )
            ok = False

    # 关系断言（不是"挂了没有"）：收件箱的**路二**要接管 `acps_delegate`，
    # 挂在**没有**该工具的角色上就是死代码；反过来，**会委派却没挂它**，
    # 图片字节就永远到不了下游（模型工具层只认 uri，字节只能由代码塞）。
    # ⚠️ 本项目已有前车之鉴：`DebateChainGuardHooks` 曾挂在没有 `acps_delegate`
    #    的辩手身上，整整空转了一轮真机。**先问"谁来调它"，再问"调了管不管用"。**
    ev_inbox_hook = ev_hooks.get(ev_inbox_id)
    if ev_inbox_hook is not None:
        takes_over = bool(getattr(ev_inbox_hook, "delegate_tool", ""))
        if ev_deleg != takes_over:
            print(
                "  [失败] 证据鉴证 Leader 的委派能力与收件箱接管不匹配："
                f"会委派={ev_deleg} 接管={takes_over}"
                "（会委派却不接管 ⇒ 材料送不出去；不委派却接管 ⇒ 死代码）"
            )
            ok = False
        else:
            print("  [通过] 证据鉴证 Leader：会委派 ⇔ 收件箱接管 acps_delegate")

    # 链深：主控(1) → 证据鉴证 Leader(2) → 图像鉴伪(3)，**正好等于上限**。
    # 这条断言的意思不是"现在能跑"，而是"**再往下挂一级就会撞墙**"：
    # 将来加 audio/video 时若想再插一层，必须先改 `MAX_CHAIN_DEPTH` 并重估环检测。
    if MAX_CHAIN_DEPTH < 3:
        print(
            f"  [失败] 链深上限 {MAX_CHAIN_DEPTH} < 3："
            "「主控 → 证据鉴证 Leader → 图像鉴伪」这条链会被熔断拒绝"
        )
        ok = False
    else:
        print(
            f"  [通过] 证据链深度 3 ≤ 上限 {MAX_CHAIN_DEPTH}"
            "（已到顶：加模态时不要再插层级）"
        )

    # 方案 A 的全部收益是「主控只认识**一个**鉴伪入口」。
    # 正向判据：主控必须认识「证据鉴证 Leader」。
    # 反向判据：主控的 instructions 里**不得出现**下游专家的注册名 ——
    #   它一旦知道这个名字，就会绕过 Leader 直接派发，这一层就被架空了。
    #   （写"不得出现"而不是"不得直接派发"是因为后者要靠语义判断，判不了；
    #     而"知不知道这个名字"是**可判**的结构事实。）
    #
    #   ⚠️ 两侧的清单**都从模态枚举现场派生**，一个手抄的名字都没有：
    #      反向 = 各 Partner **自己注册的** `display_name`（断言的是"两边名字一致"，
    #             而不是"我抄对了没"）；
    #      正向 = 分支标签 `f"{模态}鉴伪分支"`（与 Partner 名共用同一套词）。
    #      加一个模态时这两条会一起跟上；只加角色不加分支、或反过来在分支里写回
    #      下游注册名，都会让绿变红。
    leaked_names = _leader_leaked_partner_names()
    missing_branches = _leader_missing_branches()
    if "证据鉴证 Leader" not in LEADER_INSTRUCTIONS:
        print(
            "  [失败] 主控 instructions 不认识「证据鉴证 Leader」"
            "（证据链断在顶层，用户看不到鉴伪能力）"
        )
        ok = False
    elif leaked_names:
        # ⚠️ 只查图像那一个时，"顺手在新写的音频 / 视频分支里写下游注册名"这种做法
        #    **不会被任何断言拦下** —— 而后果一模一样：主控知道名字就会绕过
        #    证据鉴证 Leader 直接派发。
        print(
            "  [失败] 主控 instructions 里出现了下游专家的注册名"
            "（" + "、".join(_quote(n) for n in leaked_names) + "）"
            "（它一旦知道这个名字就会绕过证据鉴证 Leader 直接派发，方案 A 被架空）"
        )
        ok = False
    elif missing_branches:
        # 只加角色、不加分支的后果，是那条链从顶层就断了 —— 而所有离线断言
        # （角色建起来了、Hook 挂对了、端口登记了）仍然全绿。
        print(
            "  [失败] 主控 instructions 里没有这些鉴伪分支："
            + "、".join(_quote(lbl) for lbl in missing_branches)
            + "（角色建好了，但用户带这类材料来时主控不知道该往哪派 —— 断在顶层）"
        )
        ok = False
    else:
        print(
            "  [通过] 主控只认「证据鉴证 Leader」一个鉴伪入口"
            f"（{len(EvidenceModality)} 条分支都在："
            + " + ".join(m.value for m in EvidenceModality)
            + "），且不知道下游专家的注册名"
        )

    # ③ 误导性话术齐全（两层：证据层 4 + 修辞层 6）
    #
    # ⚠️ 这里原来是 `kinds == want`（**精确相等**），已改成"至少包含"。原写法的毛病：
    #    · 新增一层话术时它会报「话术类型缺失：[]」—— 缺失集**是空的**，
    #      报出来的失败信息指错方向（明明是"多了"，却说"缺了"）；
    #    · 它把"枚举里出现了别的值"当成缺陷，而枚举本来就会长。
    #    真正要守的是"**不许少**"（少一类就少一课）；"多了什么"由下面分层检查去看。
    kinds = {k.value for k in FallacyKind}
    want = {k.value for k in FALLACY_EVIDENCE_KINDS}
    if want <= kinds:
        print(f"  [通过] 证据层话术齐全（{len(want)} 类）：{sorted(want)}")
    else:
        print(f"  [失败] 证据层话术缺失：{sorted(want - kinds)}（反诈辨识会少一课）")
        ok = False
    rhet = {k.value for k in FALLACY_RHETORIC_KINDS}
    if rhet <= kinds:
        print(f"  [通过] 修辞层话术齐全（{len(rhet)} 类）：{sorted(rhet)}")
    else:
        print(f"  [失败] 修辞层话术缺失：{sorted(rhet - kinds)}")
        ok = False
    # 新增了话术却忘了归层 —— 前端按层分组时它会**静默消失**（不报错、只是不显示）
    unlayered = sorted(k for k in kinds if not fallacy_layer(k))
    if unlayered:
        print(f"  [失败] 有话术没有归层：{unlayered}（前端分组会把它丢掉）")
        ok = False

    # ④ 裁定书契约的关键字段
    need = {"verdict", "confidence", "fallacies", "basis", "disputed_points"}
    fields = set(FactRuling.model_fields)
    if need <= fields:
        print(f"  [通过] 裁定书契约含关键字段：{sorted(need)}")
    else:
        print(f"  [失败] 裁定书缺字段：{sorted(need - fields)}")
        ok = False

    # ⑤ 受理契约必须带「可判真假的命题」
    if "proposition" in ArbitrationCase.model_fields:
        print("  [通过] 受理契约含 proposition（事件先被加工成可判真假的命题）")
    else:
        print("  [失败] 受理契约缺 proposition —— 含混传闻没法被裁定")
        ok = False

    # ⑥ discovery 是**全网**语义检索，instructions 必须按 name 钉住自己人。
    #    实测查「辩论 反驳」返回 7 条只有 1 条是本项目的；不钉名字，模型就会
    #    抓到外部团队的同类 Agent，被委派边界拒绝后白烧预算（裁判只有 6–8 步）。
    #    ⚠️ 护栏在代码里（身份闸门）只是兜底，**省预算的那一半必须写在提示词里**。
    #
    #    ⚠️ ⑥-补 软废弃（2026-10-02）：主控不再委派两位专家，改为自己完成三项判定。
    #       但**平台注册保留** ⇒ discovery 依然可能召回它们 ⇒ 提示词必须**显式写明
    #       "已停用、不得委派"**。不写这一句，"废弃"就只废了一半：模型照样会把它们
    #       找回来、派出去、再等一个本不该存在的下游（本项目已实测过这类失败 ——
    #       主控一轮里派出 3 位、只等 2 位，第三位的结论永远进不了回答）。
    #       注意这与下面"钉住自己人"是**方向相反**的两件事：一个要求认得自己人，
    #       一个要求避开已停用的人 —— 所以分开断言，不要合并成一条。
    retired = ["煽动性识别", "社会危害性评估"]
    if "已停用" not in LEADER_INSTRUCTIONS:
        print(
            "  [失败] 主控 instructions 没声明两个专家已停用 —— "
            "discovery 仍能召回它们，模型会照派（软废弃最容易漏掉的一半）"
        )
        ok = False
    elif not all(n in LEADER_INSTRUCTIONS for n in retired):
        print(
            f"  [失败] 停用声明没点名到具体角色：缺 "
            f"{[n for n in retired if n not in LEADER_INSTRUCTIONS]}"
            "（不点名，模型不知道'已停用'说的是谁）"
        )
        ok = False
    else:
        print(f"  [通过] 主控 instructions 已声明 {len(retired)} 个软废弃专家并禁用委派")

    pinned = {
        # ⚠️ 主控现在**有两个可能的下游分支**（事实核查 → 网络裁判 / 鉴伪 →
        #    证据鉴证 Leader），两个名字都要钉住 —— 少写一个，那条分支就会
        #    在 discovery 的全网检索里抓到别人的同类 Agent，白烧预算。
        "leader（主控）": (LEADER_INSTRUCTIONS, ["网络裁判", "证据鉴证 Leader"]),
        "fact-judge（裁判）": (FACT_JUDGE_INSTRUCTIONS, ["辩论正方", "辩论反方"]),
        # ⚠️ 证据鉴证 Leader 的下游**按模态分支**，名字表**从模态枚举现场派生**
        #    （`_modality_partner_names`，取的是 Partner 自己注册的 `display_name`）。
        #    手抄一份的后果：加模态时它不报错，只是让新模态在 discovery 的全网检索里
        #    抓到别的团队的同类 Agent —— 而 Leader 的预算只有 8 步。
        "evidence-leader（证据鉴证）": (
            EVIDENCE_LEADER_INSTRUCTIONS, _modality_partner_names()
        ),
    }
    for who, (text, names) in pinned.items():
        # ⚠️ 空名字必须单独报：`"" in text` 恒为真，一条空名字会让"钉住下游"
        #    这条断言**静默通过**（比如某个 Partner 被删了、`display_name` 取不到）。
        blanks = [i for i, n in enumerate(names) if not n]
        missing = [n for n in names if n and n not in text]
        if blanks:
            print(
                f"  [失败] {who} 的下游名单里有 {len(blanks)} 个空名字（位置 {blanks}）—— "
                "空名字在子串判定里恒为真，会让这条断言静默通过"
            )
            ok = False
        if missing:
            print(
                f"  [失败] {who} 的 instructions 没有按 name 钉住自己人：缺 {missing}"
                "（discovery 会返回别人的同类 Agent，白烧步数）"
            )
            ok = False
        if not blanks and not missing:
            print(f"  [通过] {who} 的 instructions 已按 name 钉住 {len(names)} 个下游")

    # ⑦ 模态接线：**四处同一事实，全部现场派生**（2026-10-02 加视频时新增）。
    #
    #    同一个事实在这里散成四处（见 `_modality_rows` 的 docstring）。加一个模态只改
    #    其中两处**不会报任何错** —— 症状只是那个模态的材料收不进来 / 派不出去，
    #    而链路上每一环看起来都是成功的。所以这里一律"从枚举派生"，不手抄清单。
    rows = _modality_rows()

    # ⑦-1 枚举 ⇔ 证据角色清单，**两个方向都查**：
    #      · 枚举里有的模态必须有 `evidence-<kind>` 角色 → 否则该模态的材料没人接；
    #      · `evidence-*` 角色必须有对应枚举成员 → 否则它是个**孤儿**：
    #        建起来了、端口也占了、提示词里也有它，但永远没有任何模态能派到它。
    live_roles = {r for r in BUILDERS if r.startswith("evidence-")}
    want_roles = {"evidence-leader"} | {r.role for r in rows}
    if live_roles != want_roles:
        print(
            "  [失败] 模态枚举与证据角色清单不同步："
            f"多出 {sorted(live_roles - want_roles)}、缺 {sorted(want_roles - live_roles)}"
            "（缺 = 该模态的材料没人接；多 = 孤儿角色，永远收不到活）"
        )
        ok = False
    else:
        print(
            f"  [通过] {len(rows)} 个模态 ⇔ {len(live_roles)} 个证据角色"
            f"（{'、'.join(sorted(live_roles))}）"
        )

    # ⑦-2 每个模态的下游必须有一个**非空**注册名 —— 空名字在子串判定里恒为真。
    blank_roles = sorted(r.role for r in rows if not r.partner_name)
    if blank_roles:
        print(
            f"  [失败] 这些模态的下游没有注册名：{blank_roles}"
            "（角色没建起来 / 没有 display_name ⇒ 「钉住下游」那条断言会静默通过）"
        )
        ok = False
    else:
        print(
            "  [通过] 每个模态的下游都有非空注册名："
            + "、".join(_quote(r.partner_name) for r in rows)
        )

    # ⑦-3 收件箱要收的模态：叶角色 ⊇ 自己的模态，Leader ⊇ 全部模态。
    #      最容易漏的正是**第三处** —— 忘了列进 `kinds`，那种附件就收不进来 ⇒
    #      模型看不到句柄 ⇒ 派发时无字节可带 ⇒ 下游回一句"没有材料可看"，
    #      **而链路上每一环看起来都是成功的**。
    kind_problems: list[str] = []
    for r in rows:
        if r.agent is not None and r.modality.kind not in r.inbox_kinds:
            kind_problems.append(
                f"{r.role} 的 kinds={r.inbox_kinds} 不含 {r.modality.kind!r}"
            )
    leader_kinds = tuple(getattr(ev_inbox_hook, "kinds", ()) or ())
    all_kinds = {r.modality.kind for r in rows}
    missing_at_leader = sorted(all_kinds - set(leader_kinds))
    if missing_at_leader:
        kind_problems.append(
            f"证据鉴证 Leader 的 kinds={leader_kinds} 缺 {missing_at_leader}"
        )
    if kind_problems:
        print(
            "  [失败] 收件箱没把模态收全：" + "；".join(kind_problems)
            + "（附件收不进来 ⇒ 下游只能回「没有材料可看」，且每一环都像成功）"
        )
        ok = False
    else:
        print(
            f"  [通过] 收件箱覆盖全部 {len(all_kinds)} 个模态："
            f"各叶角色收自己的，Leader 收 {'、'.join(sorted(all_kinds))}"
        )

    # ⑦-3b 模态画像表（`KIND_PROFILES`）也必须覆盖全部模态。
    #      ⚠️ 漏一项**不会报错**：`profile_for` 会退化成一份中性画像
    #      （`part_class="FilePart"`、`uri_arg="material_uri"`），于是下游收到的是
    #      "一份文件"而不是"一段视频"，而且它还会被塞进一个**不存在**的工具参数名里 ——
    #      这种失败在日志里只表现为"模型没调用工具"。所以要在**编译期**就把它钉住。
    missing_profiles = sorted(all_kinds - set(KIND_PROFILES))
    if missing_profiles:
        print(
            f"  [失败] 模态画像表缺项：{missing_profiles}"
            "（`profile_for` 会静默退化成中性画像 ⇒ 下游收到 FilePart + 一个不存在的参数名）"
        )
        ok = False
    else:
        print(
            f"  [通过] 模态画像表覆盖全部 {len(all_kinds)} 个模态："
            + "、".join(f"{k}({KIND_PROFILES[k].counter})" for k in sorted(all_kinds))
        )

    # ⑦-3c 多模态角色**绝不许**把没登记模态的附件猜成第一顺位模态
    #      （原写法 `self.kinds[0]`：主控 / 证据鉴证 Leader 的 kinds 是
    #       ("image","audio","video")，一份视频查不到模态时会被说成"图片"、
    #       句柄被写进 `image_uri`，日志里只表现为"模型没调用工具"）。
    #      单模态角色（`kinds` 只有一项）允许沿用那一项 —— 那时猜与不猜等价，
    #      而退回中性口径反而会让下游收到 `FilePart`、按模态分派找不到它。
    #      ⚠️ 判据是**行为**（真调一次 `_fallback_kind()`），不是"源码里有没有那行"。
    from .evidence_hooks import UNKNOWN_KIND

    guessers: list[str] = []
    for role, agent in sorted(_role_agents().items()):
        hook = next(
            (h for h in getattr(agent, "hooks", [])
             if getattr(h, "id", "") == "legal.evidence-inbox"),
            None,
        )
        if hook is None:
            continue
        kinds = tuple(getattr(hook, "kinds", ()) or ())
        if len(kinds) <= 1:
            continue
        got = hook._fallback_kind()  # noqa: SLF001 - 这里要验的正是它的行为
        if got != UNKNOWN_KIND:
            guessers.append(f"{role}（kinds={kinds} → 兜底成 {got!r}）")
    if guessers:
        print(
            "  [失败] 这些多模态角色会把「类型未登记」的附件猜成一个具体模态："
            + "；".join(guessers)
            + "（猜错的代价是注入给模型的参数名指向 `image_uri` ⇒ 日志里只看到"
              "「模型没调用工具」）"
        )
        ok = False
    else:
        print(
            "  [通过] 多模态角色的附件兜底走**中性口径**（不猜第一顺位）；"
            "单模态角色仍沿用唯一那一项"
        )

    # ⑦-4 落点上限不变量：收件箱（落点）必须**至少**能吃下每一条取用方能吃下的
    #      最大字节数。反了会怎样：材料在**落点**就被拒，理由却写成"太大" ——
    #      而它其实只是超过了某一个取用方的上限，调用方完全看不懂该改哪一头。
    #      （2026-10-02 加视频时把落点从 16 MiB 抬到 64 MiB，正是因为视频链的
    #        「声明长度 vs 实际长度」判据**必须拿到完整文件**，不能截断。）
    #
    #      ⚠️ 先查"每个模态都登记了取用方模块"再算上限：漏登记就**报失败**，
    #        不是静默跳过 —— 那正是这条不变量最容易被绕过去的方式。
    unregistered = sorted(all_kinds - set(_FETCH_MODULE_BY_KIND))
    if unregistered:
        print(
            f"  [失败] 这些模态没有登记取用方模块：{unregistered}"
            "（`_FETCH_MODULE_BY_KIND` 缺项 ⇒ 上限不变量会**静默跳过**它）"
        )
        ok = False
    else:
        limits: dict[str, int] = {}
        limit_problems: list[str] = []
        for kind, path in sorted(_FETCH_MODULE_BY_KIND.items()):
            module = importlib.import_module(path)
            names = sorted(
                n for n in vars(module) if re.fullmatch(r"MAX_[A-Z0-9_]*BYTES", n)
            )
            if not names:
                limit_problems.append(f"{path} 里找不到 `MAX_*BYTES` 上限常量")
                continue
            # 一个模块里万一有多个上限：取最大值 —— 那才是"取用方能吃下的最大字节数"。
            limits[kind] = max(getattr(module, n) for n in names)
        if limit_problems:
            print(f"  [失败] 取用方上限读不出来：{'；'.join(limit_problems)}")
            ok = False
        else:
            biggest_kind = max(limits, key=lambda k: limits[k])
            biggest = limits[biggest_kind]
            detail = "、".join(f"{k}={_mib(limits[k])} MiB" for k in sorted(limits))
            if MAX_STAGE_BYTES < biggest:
                print(
                    f"  [失败] 落点上限 {_mib(MAX_STAGE_BYTES)} MiB < 取用方上限最大值"
                    f"（{biggest_kind} {_mib(biggest)} MiB）：材料会在**落点**被拒，"
                    f"理由却写成「太大」—— 而它只是超过了 {biggest_kind} 的上限"
                )
                ok = False
            else:
                print(
                    f"  [通过] 落点上限 {_mib(MAX_STAGE_BYTES)} MiB ≥ 各链取用方上限"
                    f"（{detail}）"
                )

    # ⑦-5 视频降级 Hook（PPT 4-11 的 `ContentTransform`）：**凡可能看到入站
    #      `VideoPart` 的角色都必须挂**。
    #
    #      判据**现场派生**，不手抄名单：单一事实源是"该角色的收件箱收不收 video"
    #      —— 视频字节只从收件箱那条路进来，所以"收 video" ⇔ "会看到 VideoPart"。
    #      `VIDEO_CAPABLE_ROLES` 是它的一个**声明式副本**，两者必须一致
    #      （副本漂了就等于文档在骗人）。
    #
    #      ⚠️ 少挂一个的后果**实测**（`tools/verify_video.py` 第 12 节）是
    #      `UnsupportedContentError: … cannot accept 'video' content for role 'user'`
    #      ⇒ **整个 run 抛异常**，用户得到的是一句"服务异常"。
    #      这不是"少一条线索"，所以它必须是**编译期就红**的一条。
    agents_by_role = _role_agents()
    sees_video = sorted(
        r for r, a in agents_by_role.items() if "video" in _inbox_kinds_of(a)
    )
    declared_video = sorted(VIDEO_CAPABLE_ROLES)
    if sees_video != declared_video:
        print(
            "  [失败] 「谁会看到视频」与声明不一致："
            f"实测收 video 的角色 {sees_video} vs 声明 {declared_video}"
            "（声明漂了，下一个维护者就会照错的名单去挂 Hook）"
        )
        ok = False
    missing_fallback = [
        r for r in sees_video
        if "legal.video.fallback" not in _hook_ids_of(agents_by_role[r])
    ]
    if missing_fallback:
        print(
            f"  [失败] 这些角色会收到视频字节却没挂视频降级 Hook：{missing_fallback}"
            "（实测后果是 `UnsupportedContentError` ⇒ 整个 run 抛异常，不是少一条线索）"
        )
        ok = False
    if not missing_fallback and sees_video == declared_video:
        print(
            f"  [通过] 视频降级 Hook 覆盖全部 {len(sees_video)} 个会看到视频的角色"
            f"（{'、'.join(sees_video)}）"
        )

    # ⑦-6 从**命令行**真的启得动每一个已注册角色 —— 2026-10-03 的实测教训。
    #
    #      `run_agent` 原先把 `--role` 的可选值抄成一张字面量表，抄到
    #      `evidence-image` 就没接着抄 ⇒ 那天注册 evidence-leader / audio / video
    #      三个角色时，三条命令**全被 argparse 拒掉**（exit 2，屏幕上只有一行
    #      `invalid choice`）；而调用方又把输出 `| grep` 掉、用管道吃掉了退出码
    #      ⇒ 看上去"整批注册跑完了"，实际一个都没提交。
    #      现在 `run_agent` 的 choices 由 `BUILDERS` 派生（结构上不可能忘），
    #      这里补的是**行为级**那一半：真跑一次 CLI，把 argparse 回显的可选值
    #      与 `BUILDERS` 逐个对一遍。
    #      （只看源码里有没有写 `choices=sorted(BUILDERS)` 是**自省**，
    #       不属于行为断言 —— 本项目不认那种。）
    import os
    import sys

    proc = subprocess.run(
        [sys.executable, "-m", "legal_acps.run_agent", "__no_such_role__"],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        cwd=str(Path(__file__).resolve().parents[1]),
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    # argparse 会把可选值原样回显：(choose from 'incitement', 'harm', ...)
    listed = set(re.findall(r"'([a-z0-9][a-z0-9\-]*)'", proc.stderr or ""))
    unlisted = sorted(set(BUILDERS) - listed)
    if proc.returncode == 0 or unlisted:
        print(
            f"  [失败] 命令行启不动这些已注册角色："
            f"{unlisted or '（传入不存在的角色却没报错 —— CLI 失去了这道闸门）'}"
        )
        ok = False
    else:
        print(
            f"  [通过] `run_agent --role` 覆盖全部 {len(BUILDERS)} 个已注册角色"
            "（清单由 `BUILDERS` 现场派生，加角色不可能漏）"
        )

    return ok


def check_agents() -> bool:
    section("2. Agent 编译与工具接线")
    ok = True
    for role in BUILDERS:
        agent = BUILDERS[role](DUMMY_MODEL)
        # 传 acps= 才会生成 ACS 草稿；不传则 CompiledAgent.acs_draft 为 None
        compiled = agent.compile(workspace=f".wit/{role}", acps=build_config(role=role))
        tools = [t.name for t in compiled.tools]
        draft = compiled.acs_draft or {}
        skills = [s["id"] for s in draft.get("skills", [])]
        diags = [(d.level, d.message) for d in compiled.diagnostics]

        print(f"\n  [{role}] agent_id = {compiled.agent_id}")
        print(f"        对外技能(ACS skills) = {skills}")
        print(f"        模型可调用工具        = {tools}")
        if compiled.hooks:
            print(f"        生命周期 Hook        = {[h.id for h in compiled.hooks]}")
        # 注意：acps_discover / acps_delegate / acps_task 是 AipDelegationHooks
        # 在每次 run 开始时注入的，不会出现在编译期的 tools 列表里。
        # 所以这里检查的是"委派 Hook 是否挂上"，而不是"工具是否存在"。
        hook_ids = [h.id for h in compiled.hooks]
        if role in ("leader", "fact-judge", "evidence-leader"):
            if not any(h.startswith("acps.aip.delegation") for h in hook_ids):
                print(f"    [失败] {role} 未挂载 AipDelegationHooks，将无法发现和委派 Partner")
                ok = False
            else:
                print("    [通过] 已挂载委派 Hook；acps_discover/acps_delegate/acps_task")
                print("           将在每次 run 开始时注入给模型（编译期不可见属正常）")
        # —— AMP 扩展 Hook：访问记录（2026-09-30 发现）——
        #    wit 的 access 记录是 **opt-in** 的：不挂 `AmpAccessLoggingHooks`，
        #    runtime 的 `_amp_direct_access_observer()` 就返回 None，
        #    `.wit/<role>/logs/` 里只剩 heartbeat/system，**平台侧访问次数永远是 0**。
        #    而「应用成效 10 分」与「附加分③ 访问频次 4 分」都吃这份数据 ——
        #    项目此前一处都没挂，所以"零访问"不是平台不记，是没启用。
        amp_ids = [getattr(h, "id", "") for h in compiled.amp_hooks]
        if not any(a == "acps.amp.access" for a in amp_ids):
            print(f"    [失败] {role} 未挂 AmpAccessLoggingHooks —— 平台访问次数会永远为 0")
            ok = False
        else:
            print("    [通过] 已挂 AMP 访问记录 Hook（acps.amp.access）")

        if diags:
            print(f"    [警告] 诊断信息：{diags}")
            if any(lv == "error" for lv, _ in diags):
                ok = False
    if ok:
        print(f"\n  [通过] {len(BUILDERS)} 个 Agent 全部编译成功，无 error 级诊断")
    return ok


def check_guards() -> bool:
    """自检两个"防翻车"机制：终止强制 + 辩论熔断。

    这两处都是**自己补的协议空缺 / 逻辑护栏**，一旦被误删，现象是"演示时才炸"，
    所以必须能在离线自检里一眼看出来。
    """
    section("2b. 护栏自检（终止强制 / 辩论熔断）")
    ok = True

    # —— 终止强制 Hook 是否挂在了该挂的角色上
    #
    # 2026-09-29 两级嵌套改造后的分工：
    #   leader      外层 Leader → 出 FinalVerdict
    #   fact-judge  内层 Leader → 出 FactRuling（新增；此前由 debate-pro 兼任裁判）
    #   debate-{pro,con}  叶子辩手 → 出 DebateArgument（各自一轮论点）
    #
    # ⚠️ 辩手**也必须挂**终止强制。它们虽然不再有下游，但"必须把论点交回"这件事
    #    同样不能只靠提示词 —— 改造时一度把这层摘了，等于把"模型愿意调才调"
    #    当成保证，裁判可能收到空论点。
    expected = {
        "leader": ("legal.termination-guard", "legal_issue_verdict"),
        "fact-judge": ("legal.termination-guard", "fact_issue_ruling"),
        "debate-pro": ("legal.termination-guard", "debate_submit_argument"),
        "debate-con": ("legal.termination-guard", "debate_submit_argument"),
    }
    for role, (hook_id, tool) in expected.items():
        agent = BUILDERS[role](DUMMY_MODEL)
        hooks = {h.id: h for h in agent.hooks}
        guard = hooks.get(hook_id)
        if guard is None:
            print(f"  [失败] {role} 缺少 {hook_id}（下游/辩手返回后将不保证有交付物）")
            ok = False
            continue
        actual = getattr(guard, "conclusion_tool", None)
        if tool and actual != tool:
            print(f"  [失败] {role} 的强制工具应为 {tool}，实际 {actual}")
            ok = False
        else:
            print(f"  [通过] {role} 已挂 {hook_id}（强制工具 {actual}）")

    # —— 两位辩手都必须是**纯 Partner**：
    #    · 必须保留链熔断（否则委托链会无限延伸）；
    #    · 不得挂委派 Hook（组织辩论是裁判的职责，辩手不该发起子会话）；
    #    · 兜底必须关闭（第 5 层只会拼 FinalVerdict 形状，辩手走它就会往
    #      output/ 塞"看着像主控结论"的文件，污染唯一判据）。
    for role in ("debate-pro", "debate-con"):
        agent = BUILDERS[role](DUMMY_MODEL)
        hooks = {getattr(h, "id", ""): h for h in agent.hooks}
        has_chain = "legal.debate.chain-guard" in hooks
        has_deleg = any(k.startswith("acps.aip.delegation") for k in hooks)
        guard = hooks.get("legal.termination-guard")
        fallback_off = guard is not None and getattr(guard, "fallback_on_failure", None) is False
        checks = [
            (has_chain, "已挂链熔断（纯 Partner 定位）"),
            (not has_deleg, "未挂委派 Hook（组织辩论是裁判的职责）"),
            (fallback_off, "交付物兜底已关闭（不会往 output/ 塞伪结论）"),
        ]
        for good, why in checks:
            if not good:
                print(f"  [失败] {role}：{why}")
                ok = False
            else:
                print(f"  [通过] {role}：{why}")

    # —— 内层 Leader 的步数预算：`reserve_steps` 语义是"还剩几步就开始兜底"，
    #    值越大触发越早。裁判完整流程要 7 步（受理→发现→派发正→等正→派发反→等反→裁定），
    #    若把它设成 2，第 6 步（"等反方"那一步）就会被锁成裁定书 ——
    #    反方论点还没拿到就被迫裁定，对抗性检验塌成单方陈述。
    #    这是**行为断言**：同样在第 6 步，参数错了这里就会拿到 budget-guard。
    judge_guard_for_budget = next(
        (
            h
            for h in BUILDERS["fact-judge"](DUMMY_MODEL).hooks
            if getattr(h, "id", "") == "legal.termination-guard"
        ),
        None,
    )
    if judge_guard_for_budget is None:
        print("  [失败] fact-judge 上找不到 legal.termination-guard")
        ok = False
    else:
        got_rs = getattr(judge_guard_for_budget, "reserve_steps", None)
        if got_rs != 0:
            print(
                f"  [失败] 裁判的 reserve_steps 应为 0（只在最后一步兜底），实际 {got_rs}"
                " —— 会在反方论点到达前就强制出裁定"
            )
            ok = False
        else:
            print("  [通过] 裁判 reserve_steps=0（不会劫持「等反方」那一步）")

    # —— 强制文案里的字段名必须与角色契约一致
    #    裁判的 FactRuling 没有 consistency_note 字段，写死会让系统指错地方
    if judge_guard_for_budget is not None and getattr(
        judge_guard_for_budget, "note_field", None
    ) == "consistency_note":
        print("  [失败] 裁判的强制文案仍在指示写 consistency_note（FactRuling 没有该字段）")
        ok = False
    else:
        print("  [通过] 裁判的强制文案指向 FactRuling 真实存在的字段")

    # —— 终止判定：三条条件各测一遍
    def arg(round_, stance, conf):
        from .contracts import DebateArgument, DebateStance

        return DebateArgument(
            round=round_,
            stance=DebateStance(stance),
            confidence=conf,
            key_point="probe",
        )

    probes = [
        ("轮数上限", [arg(DEBATE_MAX_ROUNDS, "hold", 0.9)], True),
        ("认输", [arg(1, "hold", 0.9), arg(1, "concede", 0.4)], True),
        ("连续塌陷", [arg(1, "hold", 0.9), arg(2, "hold", 0.7), arg(2, "hold", 0.2)], True),
        ("正常继续", [arg(1, "hold", 0.9), arg(2, "hold", 0.85)], False),
    ]
    for label, history, expect_stop in probes:
        got = should_terminate(history).stop
        mark = "通过" if got == expect_stop else "失败"
        if got != expect_stop:
            ok = False
        print(f"  [{mark}] 终止判定 · {label}：stop={got}（期望 {expect_stop}）")

    # —— 链深熔断 / 环检测
    chain_probes = [
        ("正常跳", (("A",), "B"), True),
        ("环 A→B→A", (("A", "B"), "A"), False),
        ("超深度", (("A", "B", "C"), "D"), False),
    ]
    for label, (chain, target), expect_ok in chain_probes:
        try:
            hop = plan_next_hop(chain, target)
            got_ok, detail = True, f"depth={hop.depth}"
        except DebateChainError as exc:
            got_ok, detail = False, str(exc)[:36]
        mark = "通过" if got_ok == expect_ok else "失败"
        if got_ok != expect_ok:
            ok = False
        print(f"  [{mark}] 委托链 · {label}：放行={got_ok}（{detail}）")

    # —— 终止强制：默认**不得**使用 tool_choice
    #    推理模型（DeepSeek thinking）会直接 HTTP 400，整轮 run 崩掉（2026-09-29 实测）
    guard = next(
        (
            h
            for h in BUILDERS["leader"](DUMMY_MODEL).hooks
            if getattr(h, "id", "") == "legal.termination-guard"
        ),
        None,
    )
    if guard is None:
        print("  [失败] leader 上找不到 legal.termination-guard")
        ok = False
    elif getattr(guard, "force_tool_choice", None) is not False:
        print("  [失败] 终止 Hook 默认开启了 tool_choice（推理模型会 400 崩掉）")
        ok = False
    else:
        print("  [通过] 终止强制默认不用 tool_choice（改为收敛可用工具，兼容推理模型）")

    # —— 第 5 层兜底：能从专家载荷拼出一份合规结论
    from .termination import build_fallback_verdict, collect_partner_payloads

    class _FakeToolMessage:
        """顶替 wit 的 role=tool 消息：只要 role/name/text() 三个即可。"""

        def __init__(self, payload: dict) -> None:
            self.role = "tool"
            self.name = "acps_task"
            self._payload = payload

        def text(self) -> str:
            return json.dumps(self._payload)

    def _obs(task_ref: str, data: dict) -> "_FakeToolMessage":
        return _FakeToolMessage(
            {
                "status": "success",
                "modelToolName": "acps_task",
                "result": {
                    "task_ref": task_ref,
                    "state": "awaiting-completion",
                    "products": [{"type": "data", "data": data}],
                },
            }
        )

    fallback_msgs = [
        _obs("t1", {"is_incitement": True, "overall_truth_score": 40}),
        _obs("t2", {"harm_index": 70, "dimensions": {}}),
    ]
    payloads = collect_partner_payloads(fallback_msgs)
    if payloads.harm is None or payloads.incitement is None or payloads.truth is None:
        print("  [失败] 第 5 层兜底解析不到专家载荷（模型拒不交付时会没有结论）")
        ok = False
    else:
        verdict = build_fallback_verdict(
            subject="probe", payloads=payloads, reason="check_local"
        )
        good = (
            verdict["harm_index"] == 70
            and verdict["is_incitement"] is True
            and verdict["truth_score"] == 40
            and "兜底" in verdict["consistency_note"]
        )
        if not good:
            ok = False
        print(
            f"  [{'通过' if good else '失败'}] 第 5 层兜底：能从专家载荷拼出结论"
            f"（harm_index={verdict['harm_index']}, is_incitement={verdict['is_incitement']},"
            f" truth_score={verdict['truth_score']}）"
        )

    # -----------------------------------------------------------------
    # 以下两组探针是 2026-09-29 审计发现真实缺陷后补的：
    # 之前只校验"Hook 的构造参数对不对"，不校验"参数有没有真的被用上"，
    # 于是两个缺陷都逃过了自检。现在都改成**行为断言**。
    # -----------------------------------------------------------------
    from .termination import survey

    class _ToolMsg:
        """顶替 wit 的 role=tool 消息，只需 role/name/text()。"""

        role = "tool"

        def __init__(self, tool_name: str, status: str = "success", result=None) -> None:
            self.name = tool_name
            self._status = status
            self._result = result if result is not None else {}

        def text(self) -> str:
            return json.dumps(
                {
                    "modelToolName": self.name,
                    "status": self._status,
                    "result": self._result,
                }
            )

    def _partner_done(ref: str) -> "_ToolMsg":
        return _ToolMsg("acps_task", result={"task_ref": ref, "state": "awaiting-completion"})

    def _partner_pending(ref: str) -> "_ToolMsg":
        return _ToolMsg("acps_task", result={"task_ref": ref, "state": "working"})

    def _partner_dead(ref: str) -> "_ToolMsg":
        return _ToolMsg("acps_task", result={"task_ref": ref, "state": "failed"})

    def _delegated(ref: str) -> "_ToolMsg":
        """一次**成功**的委派观测（派发当下 state=working）。"""
        return _ToolMsg("acps_delegate", result={"task_ref": ref, "state": "working"})

    def _verdict_error() -> "_ToolMsg":
        return _ToolMsg("legal_issue_verdict", status="error")

    class _FakeCtx:
        def __init__(self, messages: list, step: int | None = None) -> None:
            self.state = type("_S", (), {"messages": messages, "metadata": {}})()
            self.config = type("_C", (), {"max_steps": 8})()
            # step=None 表示"拿不到步号"（budget-guard 不参与判定）；
            # 传具体步号才能让 budget-guard 生效 —— 用于验证它与"放弃强制"的优先级。
            self.private_state = {} if step is None else {"step": step}

    # —— 缺陷 1（已修）：交付物工具必须真的参数化进判定
    #    survey() 早期写死 legal_issue_verdict，导致非 Leader 角色交了交付物
    #    却永远判不出"已交付" → 第 4 层收尾 / retry / 跳过兜底 全部失效。
    #    这里用内层 Leader（网络裁判）的交付物工具名做探针。
    custom_ok = (
        survey([_ToolMsg("fact_issue_ruling")], verdict_tool="fact_issue_ruling").verdict_submitted
        is True
        and survey([_ToolMsg("fact_issue_ruling")]).verdict_submitted is False
    )
    if not custom_ok:
        print("  [失败] survey() 没有按 verdict_tool 参数判定（非 Leader 角色的交付物会判不出来）")
        ok = False
    else:
        print("  [通过] survey() 按传入的交付物工具名判定（外层主控 / 网络裁判各认各的）")

    # —— 内层 Leader（网络裁判）交付后必须触发收尾，否则会空转到预算耗尽
    judge_guard = next(
        (
            h
            for h in BUILDERS["fact-judge"](DUMMY_MODEL).hooks
            if getattr(h, "id", "") == "legal.termination-guard"
        ),
        None,
    )
    if judge_guard is None:
        print("  [失败] fact-judge 上找不到 legal.termination-guard")
        ok = False
    else:
        decided = judge_guard._decide(_FakeCtx([_ToolMsg("fact_issue_ruling")]))
        reason = decided[0].reason if decided else None
        finish_ok = reason == "finish-after-verdict" and decided[0].clear_tools is True
        if not finish_ok:
            print(
                f"  [失败] 网络裁判出了裁定后没触发收尾（reason={reason}）"
                "—— 会继续空转到预算耗尽"
            )
            ok = False
        else:
            print("  [通过] 网络裁判出裁定后触发第 4 层收尾（reason=finish-after-verdict）")

    # —— 裁判的步数预算：**行为断言**
    #
    #   第 6 步（step=5）时反方论点还没到，绝不能被强制出裁定；
    #   到了最后一步（step=7）才允许兜底。这一对断言专门钉住
    #   "reserve_steps 语义被理解反"这个真实缺陷：
    #   早期写成 2 时，step=5 会返回 budget-guard（断言必然失败）。
    if judge_guard is not None:
        budget_cases = [
            ("反方未回 + 第 6 步 → 不得强制（要给辩论留空间）", 5, None),
            ("反方未回 + 最后一步 → 必须兜底强制", 7, "budget-guard"),
        ]
        for label, step, expect in budget_cases:
            decided3 = judge_guard._decide(_FakeCtx([_partner_done("t1")], step))
            got3 = decided3[0].reason if decided3 else None
            good3 = got3 == expect
            if not good3:
                ok = False
            print(f"  [{'通过' if good3 else '失败'}] 裁判步数预算 · {label}：reason={got3}（期望 {expect}）")

    # —— 缺陷 3（已修）：判定优先级 —— "专家已就绪"必须压过"放弃强制"
    #    早期把 verdict_errors 的放弃判定排在 partners-ready 之前，
    #    模型连错两次表单后即使专家都回来了也不再强制，只剩第 5 层兜底。
    leader_guard = next(
        (
            h
            for h in BUILDERS["leader"](DUMMY_MODEL).hooks
            if getattr(h, "id", "") == "legal.termination-guard"
        ),
        None,
    )
    # 判定优先级这一组**自己构造 Hook**：它测的是 `_decide` 的**分支优先级**
    # （"下游已就绪"必须压过"放弃强制"），与"主控现在等几位下游"无关。
    #
    # ⚠️ 旧版直接拿 `BUILDERS['leader']` 的实例来跑 ⇒ 这组断言的语义被角色参数
    #    **悄悄绑住了**：2026-10-02 主控的 `expected_partners` 由 2 改为 1
    #    （软废弃后它最多只派网络裁判一位），场景"还有一位专家没回"随之不再成立，
    #    两条断言凭空失败 —— 而它们要守的机制一条都没坏。
    #    教训：**机制单测要自带参数；角色的参数由专门的断言去守**（见本段末尾）。
    order_guard = LeaderTerminationHooks(expected_partners=2, verbose=False)
    if leader_guard is None:
        print("  [失败] leader 上找不到 legal.termination-guard")
        ok = False
    else:
        order_cases = [
            (
                "专家已就绪 + 表单连错 2 次 → 仍须强制",
                [_partner_done("t1"), _partner_done("t2"), _verdict_error(), _verdict_error()],
                "partners-ready",
                None,
            ),
            (
                "一位专家失败 + 一位返回 → 仍须强制（终态即就绪）",
                [_partner_done("t1"), _partner_dead("t2")],
                "partners-ready",
                None,
            ),
            (
                "专家未回 + 表单错 1 次 → 不得强制（强制会取不到结果）",
                [_partner_done("t1"), _partner_pending("t2"), _verdict_error()],
                None,
                None,
            ),
            # ⚠️ 2026-09-29 审计发现的缺陷：早期"放弃强制"用 return None 提前返回，
            #    顺手把预算兜底(budget-guard)也跳过了。这一步已是最后一步，
            #    必须仍走兜底 —— 否则最后一步主动放弃唯一的兜底机会。
            (
                "专家未回齐 + 表单连错 2 次 + 已是最后一步 → 预算兜底仍须生效",
                [_partner_done("t1"), _verdict_error(), _verdict_error()],
                "budget-guard",
                7,
            ),
        ]
        for label, msgs, expect, step in order_cases:
            decided2 = order_guard._decide(_FakeCtx(msgs, step))
            got = decided2[0].reason if decided2 else None
            good = got == expect
            if not good:
                ok = False
            print(f"  [{'通过' if good else '失败'}] 判定优先级 · {label}：reason={got}（期望 {expect}）")

        # —— 软废弃（2026-10-02）：主控的**预期下游数必须是 1**
        #     它不再委派任何专家，只有「事实核查」附加分支会派 1 位网络裁判。
        #     ⚠️ 判据是 `max(expected_partners, delegations)`：这里若写成 2，
        #     主控只派 1 位时 `1 >= 2` 永不成立 ⇒ 裁判把裁定书交回来了也不会触发
        #     收尾，主控只能干等到预算见底 —— 一个**不报错、只是变慢变差**的坑。
        got_ep = getattr(leader_guard, "expected_partners", None)
        if got_ep != 1:
            print(
                f"  [失败] 主控预期下游数应为 1（软废弃后最多只派网络裁判一位），"
                f"实际 {got_ep} —— partners-ready 会在只派 1 位时永不触发"
            )
            ok = False
        else:
            print("  [通过] 主控预期下游数 = 1（只等网络裁判；不再等两位专家）")

    # —— 缺陷 4（已修）：预期下游数**不能写死**，实际派出几个就得等几个
    #
    #    2026-09-30 真机逮到：主控的「事实核查」附加分支一轮里派了 **3** 位
    #    （煽动识别 / 危害评估 / 网络裁判），而 `LeaderTerminationHooks` 的
    #    `expected_partners` 只写了 2 → 前两位一交回就触发 partners-ready，
    #    本步工具被锁定为交付物，**主控再也调不了 acps_task 去等第三位**；
    #    网络裁判的裁定书晚 9 秒才落盘，没能进入主控结论。
    #
    #    判据因此改成 `max(预期下限, 本轮实际成功派出数)`：
    #      · 实际派出数 —— "我的依赖都回来了吗"的正确语义；
    #      · 预期下限   —— 防模型一次都没派时 `0 >= 0` 立刻收尾。
    #    这条断言守的是**语义**：参数（expected_partners=2）一个都没改。
    if leader_guard is not None:
        fanout_cases = [
            (
                "标准流程 2 位全回 → 必须触发",
                [_delegated("t1"), _delegated("t2"), _partner_done("t1"), _partner_done("t2")],
                "partners-ready",
            ),
            (
                "派出 3 位只回 2 位 → 不得触发（否则主控等不到第 3 位）",
                [
                    _delegated("t1"),
                    _delegated("t2"),
                    _delegated("t3"),
                    _partner_done("t1"),
                    _partner_done("t2"),
                    _partner_pending("t3"),
                ],
                None,
            ),
            (
                "派出 3 位全部到达终态（含明确失败）→ 必须触发",
                [
                    _delegated("t1"),
                    _delegated("t2"),
                    _delegated("t3"),
                    _partner_done("t1"),
                    _partner_done("t2"),
                    _partner_dead("t3"),
                ],
                "partners-ready",
            ),
            ("一位都没派 → 不得触发（下限保护）", [], None),
        ]
        for label, msgs, expect in fanout_cases:
            decided3 = leader_guard._decide(_FakeCtx(msgs, None))
            got3 = decided3[0].reason if decided3 else None
            good3 = got3 == expect
            if not good3:
                ok = False
            print(f"  [{'通过' if good3 else '失败'}] 扇出与预期 · {label}：reason={got3}（期望 {expect}）")

    # —— 缺陷 2（已修）：委派失败不得污染委托链
    #    早期版本在 await handler 之前就写链，一次网络抖动后"重试同一目标"
    #    会被误判成环，目标在本轮被永久封禁 —— 整场辩论发不起来。
    class _Call:
        def __init__(self, target: str) -> None:
            self.id = "c1"
            self.name = "acps_delegate"
            self.arguments = {"partner_aic": target}

    async def _chain_behaviour() -> tuple[bool, bool, str]:
        guard = DebateChainGuardHooks(self_aic="aic://pro@probe", max_depth=3)
        ctx = _FakeCtx([])
        seen = {"n": 0}

        async def flaky(call):
            seen["n"] += 1
            if seen["n"] == 1:
                raise RuntimeError("模拟网络抖动")
            return {"status": "success", "result": {"task_ref": "t1"}}

        try:
            await guard.wrap_tool_call(ctx, _Call("aic://con@probe"), flaky)
        except RuntimeError:
            pass
        retry = await guard.wrap_tool_call(ctx, _Call("aic://con@probe"), flaky)
        retry_allowed = retry.get("status") != "error"

        # 真环：A → B → A
        cycle_guard = DebateChainGuardHooks(self_aic="aic://A@probe", max_depth=3)
        cctx = _FakeCtx([])
        cctx.private_state["debate_chain"] = ("aic://A@probe", "aic://B@probe")

        async def never(call):
            return {"status": "success"}

        cyc = await cycle_guard.wrap_tool_call(cctx, _Call("aic://A@probe"), never)
        cycle_blocked = cyc.get("status") == "error"
        return retry_allowed, cycle_blocked, str((cyc.get("error") or {}).get("code"))

    retry_allowed, cycle_blocked, cyc_code = asyncio.run(_chain_behaviour())
    if not retry_allowed:
        print("  [失败] 委派失败后的重试被判成了环（目标会被永久封禁，辩论发不起来）")
        ok = False
    elif not cycle_blocked or cyc_code != "debate_chain_rejected":
        print(f"  [失败] 真正的委托环没被拦住（code={cyc_code}）")
        ok = False
    else:
        print("  [通过] 委托链：失败后的重试放行、真环被拒（code=debate_chain_rejected）")

    # —— 扇出 ≠ 链深（2026-09-30 真机修复后的回归断言）——
    #
    #   真机踩到的：主控的「事实核查」分支要委派 **3** 个伙伴
    #   （煽动性识别 / 社会危害性评估 / 网络裁判），而旧实现把**扇出**累加进链深
    #   → 链长变 4，撞上 MAX_CHAIN_DEPTH=3，**第 3 个委派被判"深度超限"拒绝**。
    #   后果：危害评估专家没能接入，leader 只能在结论里如实写"该系统判定委托链深度超限"。
    #
    #   AAC 语义下这三者是 **depth=2 的同级**，根本不是一条 4 层链。
    #   这条断言守的是**语义**而不是参数 —— 参数（max_depth=3）一个都没改。
    class _Fan:  # noqa: D401 —— 与上面 _Call 同形，只是名字更直白
        def __init__(self, target: str, cid: str = "c1") -> None:
            self.id = cid
            self.name = "acps_delegate"
            self.arguments = {"partner_aic": target}

    async def _fanout_behaviour() -> tuple[list[bool], bool, bool, bool]:
        async def ok_handler(call):
            return {"status": "success", "result": {"task_ref": "t"}}

        guard = DebateChainGuardHooks(self_aic="aic://L@probe", max_depth=3)
        fctx = _FakeCtx([])
        # ① 五个**同级**下游必须全部放行（旧实现在第 3 个就会拒）
        fans = []
        for i, tgt in enumerate(["A", "B", "C", "D", "E"]):
            res = await guard.wrap_tool_call(fctx, _Fan(f"aic://{tgt}@probe", f"c{i}"), ok_handler)
            fans.append(res.get("status") != "error")
        # ② 自己派自己 → 必须被拒（自环）
        s = await guard.wrap_tool_call(fctx, _Fan("aic://L@probe", "cs"), ok_handler)
        self_blocked = s.get("status") == "error"
        # ③ 跨层环：祖先路径里已有 A，B 再派 A → 必须被拒
        g2 = DebateChainGuardHooks(self_aic="aic://B@probe", max_depth=3)
        c2 = _FakeCtx([])
        c2.private_state["debate_chain"] = ("aic://A@probe", "aic://B@probe")
        c2res = await g2.wrap_tool_call(c2, _Fan("aic://A@probe", "cc"), ok_handler)
        ancestor_blocked = c2res.get("status") == "error"
        # ④ 真正的深度熔断仍必须有效：祖先已 3 层，再派一层 → 拒
        g3 = DebateChainGuardHooks(self_aic="aic://D@probe", max_depth=3)
        c3 = _FakeCtx([])
        c3.private_state["debate_chain"] = ("aic://A@probe", "aic://B@probe", "aic://C@probe")
        c3res = await g3.wrap_tool_call(c3, _Fan("aic://E@probe", "cd"), ok_handler)
        depth_blocked = c3res.get("status") == "error"
        return fans, self_blocked, ancestor_blocked, depth_blocked

    fans, self_blocked, ancestor_blocked, depth_blocked = asyncio.run(_fanout_behaviour())
    if not all(fans):
        print(
            f"  [失败] 同级扇出被误杀：5 个同级下游只放行了 {sum(fans)} 个"
            "（扇出被当成链深 —— 主控的第 3 个伙伴会永远接不上）"
        )
        ok = False
    elif not self_blocked:
        print("  [失败] 自己派给自己没被拦住（自环）")
        ok = False
    elif not ancestor_blocked:
        print("  [失败] 跨层环 A→B→A 没被拦住")
        ok = False
    elif not depth_blocked:
        print("  [失败] 真正的深度熔断失效了（祖先已 3 层还能再派）")
        ok = False
    else:
        print(
            "  [通过] 委托链语义：同级扇出不受限（5/5 放行）、自环与跨层环被拒、"
            "嵌套超深被拒"
        )

    # —— 挂载位置断言（2026-09-30 新增）——
    #
    #   这是同一天里发现的第二种"装了但不生效"：
    #   链熔断 Hook 只有挂在**会委派的** Agent 上才有效。挂在叶子节点（辩手）上，
    #   因为叶子根本没有 `acps_delegate` 这个工具，`wrap_tool_call` 永远不被触发
    #   —— 等于装了一个从不响的警报器。改造期间它一度只挂在两位辩手上，
    #   使「补上 AAC 链深约束」这个创新点在**真机上完全空转**。
    #
    #   而当时自检是全绿的：自检自己构造调用喂给 Hook，测得出"拦得住"，
    #   却测不出"线上根本没人调它"。所以这里断言的必须是**关系**，不是行为：
    #
    #       挂了 AipDelegationHooks（能委派） ⇒ 必须挂 DebateChainGuardHooks
    #
    #   这一条如果没人守，下次调整 Hook 时会以完全相同的方式静默退化。
    SELF_AIC = "1.2.156.3088.1.BUPT.81M3FX.X1J5R5.HKBBAM.018M"
    delegating_roles: list[str] = []
    guard_missing = False
    for role in BUILDERS:
        probe = build_agent(role, DUMMY_MODEL, self_aic=SELF_AIC)
        can_delegate = any(isinstance(h, AipDelegationHooks) for h in probe.hooks)
        has_guard = any(isinstance(h, DebateChainGuardHooks) for h in probe.hooks)
        if not can_delegate:
            continue
        delegating_roles.append(role)
        if not has_guard:
            print(f"  [失败] {role} 能委派却没挂链熔断/身份校验 —— 该 Hook 会被静默空转")
            ok = False
            guard_missing = True
    if not guard_missing:
        print(
            f"  [通过] 挂载位置：{len(delegating_roles)} 个会委派的 Agent"
            f"（{'、'.join(delegating_roles)}）都挂了链熔断 + 身份校验"
        )

    # —— 账号前缀派生（2026-09-30 新增）——
    #   本项目 AIC 是 10 段，账号级 = **前 7 段**（OID 5 段 + 机构 + 账号）。
    #   ⚠️ 我第一版写成"前 6 段"，只取到机构级 —— 同机构不同账号会被当成自己人。
    #   所以把这几个真实样本钉成断言（含外部的那个真实 AIC）。
    prefix_cases = [
        (
            "1.2.156.3088.1.BUPT.81M3FX.COUJXB.F9XC6K.0J6D",
            "1.2.156.3088.1.BUPT.81M3FX",
            "本项目 AIC",
        ),
        (
            "1.2.156.3088.1.0001.00001.EZTK03.PABX6D.0JUV",
            "1.2.156.3088.1.0001.00001",
            "外部团队 AIC（真实踩到的那条）",
        ),
        ("<self>", "", "占位串 → 判不出来"),
        ("", "", "空串"),
        ("1.2.3.4.5.6", "", "段数不足 → 判不出来"),
    ]
    prefix_ok = True
    for aic, want, why in prefix_cases:
        got = account_prefix_of(aic)
        if got != want:
            print(f"  [失败] 账号前缀派生 · {why}：得到 {got!r}（期望 {want!r}）")
            ok = False
            prefix_ok = False
    if prefix_ok:
        print("  [通过] 账号前缀派生：本项目 / 外部团队 / 占位串 / 段数不足，五种入参均正确")

    # —— 身份闸门：**行为断言**（2026-09-30 新增）——
    #
    #   拦的是 discovery 语义检索捞到的**外部团队 Agent**：实测查「辩论 反驳」
    #   返回 7 条，只有 1 条是本项目的反方。提示词管不住模型选谁，
    #   所以在派发边界上兜一道 —— 这里断言的就是"真的兜住了"。
    FOREIGN_AIC = "1.2.156.3088.1.0001.00001.EZTK03.PABX6D.0JUV"
    trust_guard = DebateChainGuardHooks(self_aic=SELF_AIC)
    trust_cases = [
        ("自家 AIC → 放行", SELF_AIC, None),
        ("外部 AIC → 拒绝", FOREIGN_AIC, "foreign_partner_rejected"),
        ("空目标 → 放行（交给链检测去报「目标为空」，职责分开）", "", None),
    ]
    for label, target, want_code in trust_cases:
        err = trust_guard._check_partner_trust(target)
        got_code = None if err is None else str(err.to_error().get("code"))
        good = got_code == want_code
        if not good:
            ok = False
        print(
            f"  [{'通过' if good else '失败'}] 身份闸门 · {label}：code={got_code}（期望 {want_code}）"
        )

    allowed_guard = DebateChainGuardHooks(self_aic=SELF_AIC, allowed_aics=[FOREIGN_AIC])
    if allowed_guard._check_partner_trust(FOREIGN_AIC) is not None:
        print("  [失败] 白名单里的外部 AIC 仍被拒 —— 将来无法接入外部伙伴")
        ok = False
    else:
        print("  [通过] 身份闸门 · 白名单放行：显式允许时仍可接入外部伙伴（留了活口）")

    # fail-open 是**刻意**的设计：拿不到本账号前缀时宁可不保护，也不能误杀合法委派。
    # 所以这一条的期望与上面相反 —— 它守的是"别把护栏变成误杀"。
    open_guard = DebateChainGuardHooks()
    if open_guard._check_partner_trust(FOREIGN_AIC) is not None:
        print("  [失败] 未传 self_aic 时把所有目标判成外部 —— 会把演示链路直接掐死")
        ok = False
    else:
        print("  [通过] 身份闸门 · 无身份信息时 fail-open（不误杀，只是不保护）")

    if ok:
        print("\n  [通过] 护栏齐全：结论必被提交、委托链不成环、委派只发给自己人")
    return ok



def check_protocols() -> bool:
    section("3. 协议声明与端口")
    ok = True
    for role in BUILDERS:
        agent = BUILDERS[role](DUMMY_MODEL)
        kinds = []
        for p in agent.protocols:
            if isinstance(p, AcpsDirect):
                kinds.append(f"AcpsDirect(modes={tuple(p.modes)})")
            elif isinstance(p, AcpsGroup):
                kinds.append("AcpsGroup")
            else:
                kinds.append(type(p).__name__)
        print(f"  {role:<12} port={PORTS[role]:<5} protocols={kinds}")
        if not agent.protocols:
            print(f"    [失败] {role} 没有声明任何 ACPs 协议，无法互联")
            ok = False
    ports = list(PORTS.values())
    if len(ports) != len(set(ports)):
        print("  [失败] 端口重复")
        ok = False
    if ok:
        print(f"  [通过] {len(BUILDERS)} 个角色均声明了协议，且端口不冲突")
    return ok


def check_scripts() -> bool:
    """启停脚本与文本卫生自检（2026-09-30 审计后新增）。

    同类缺陷今天连中两次，都属于"跑起来才炸、而自检全绿"的那种：

      · ``scripts/serve.sh`` 整篇是 CRLF（286 行全部 ``\\r\\n``，连 shebang 都带）——
        推上服务器后 bash 会逐行报 ``$'\\r': command not found``，脚本根本起不来；
      · ``scripts/verify.sh`` 里把角色清单**写死**成 5 个 —— 断言用的是新事实、
        打印出来的却是旧事实。**看板自己在骗人，比没有看板更糟。**

    所以这里断言三件事：
      ① ``.sh`` / ``.service`` 必须是纯 LF（bash 与 systemd 都不接受 ``\\r``）；
      ② 脚本里出现的"角色清单"必须与 ``acps_config.PORTS`` 完全一致 ——
         同一个事实散在 4 个地方（PORTS / serve.sh / systemd-install.sh /
         本文件），迟早会有一处漏改，漏了就是"新角色起不来"；
      ③ 每个角色都要有对应的 systemd 单元，且单元启动的正是它自己。
    """
    section("3b. 启停脚本与文本卫生")
    ok = True
    root = Path(__file__).resolve().parents[1]
    sh_files = sorted(root.glob("scripts/*.sh"))
    unit_files = sorted(root.glob("deploy/systemd/*.service"))
    # ⚠️ `.py` 也一并纳入（2026-09-30 补）。Python 自己两种都吃，所以**它坏起来没人管**：
    #    当天我用一个元验证脚本整篇重写了 debate.py，Windows 上 `Path.write_text()`
    #    默认文本模式会把每个 `\n` 翻成 `\r\n` → 整篇变 CRLF、并被同步到服务器，
    #    而单元测试与 import 全都正常。**"能跑"正是它危险的地方**：
    #    换行符一旦漂移，`.sh` 那套纪律就没法用同一套判据核对了。
    py_files = sorted(root.glob("legal_acps/**/*.py")) + sorted(root.glob("tools/*.py"))

    # —— ① 换行符：代码与脚本一律不许出现 CR
    cr_files = sh_files + unit_files + py_files
    dirty = [
        (p, p.read_bytes().count(b"\r"))
        for p in cr_files
        if b"\r" in p.read_bytes()
    ]
    if dirty:
        for p, n in dirty:
            why = "bash/systemd 会逐行报错" if p.suffix in (".sh", ".service") else "文本模式重写文件时被 TranslateNewline 引入"
            print(f"  [失败] {p.relative_to(root).as_posix()} 含 {n} 个 CR（CRLF）—— {why}")
        ok = False
    else:
        print(
            f"  [通过] {len(sh_files)} 个 .sh + {len(unit_files)} 个 .service + "
            f"{len(py_files)} 个 .py 均为纯 LF"
        )

    # —— ② bash 语法（能抓到真正的语法级错误；"两个 echo 挤一行"那种抓不到，
    #       那是语义错误，只能靠人读 —— 见手册 §12.6）
    bash = shutil.which("bash")
    if bash:
        broken = []
        for p in sh_files:
            proc = subprocess.run([bash, "-n", str(p)], capture_output=True, text=True)
            if proc.returncode != 0:
                first = (proc.stderr or "").strip().splitlines()
                broken.append((p, first[0] if first else "bash -n 失败"))
        if broken:
            for p, err in broken:
                print(f"  [失败] bash -n {p.relative_to(root).as_posix()}：{err}")
            ok = False
        else:
            print(f"  [通过] {len(sh_files)} 个 .sh 语法检查通过（bash -n）")
    else:
        print("  [跳过] 环境里没有 bash，跳过语法检查")

    # —— ③ 脚本里的角色清单必须**可解释**
    #     取值方式很保守：只认「括号里 ≥2 个"像角色名"的词，且至少一个真的在 PORTS 里」。
    #     后半个条件是防误报的 —— 否则 $(echo a b) 这类命令替换会被当成角色清单。
    #
    #     ⚠️ 2026-10-02 起有**三种**合法清单（软废弃引入了第二种：刻意不部署的那批）：
    #        · PORTS              —— "本项目一共定义了哪些角色"（`ALL_ROLES`）
    #        · SOFT_RETIRED       —— "刻意不部署的那几个"
    #        · PORTS − SOFT_RETIRED —— "实际要跑的"（`ROLES` / `DEPLOY_ROLES`）
    #     任何别的组合都算漂移。并要求三者严格构成一个**划分**（下面 ③-补）。
    #     这样"加了角色忘了改脚本"与"软废弃名单写错"都会被逮到。
    role_like = re.compile(r"^[a-z][a-z0-9-]*$")
    role_set = set(PORTS)
    soft_set = set(SOFT_RETIRED)
    deploy_set = set(DEPLOY_ROLES)
    allowed = {frozenset(role_set), frozenset(soft_set), frozenset(deploy_set)}
    drift: list[tuple[Path, set[str]]] = []
    for p in sh_files:
        text = p.read_text(encoding="utf-8", errors="replace")
        for m in re.finditer(r"\(([A-Za-z0-9_|\s-]+)\)", text):
            tokens = {t for t in re.split(r"[|\s]+", m.group(1)) if t}
            if len(tokens) < 2 or not all(role_like.match(t) for t in tokens):
                continue
            if not (tokens & role_set):
                continue
            if frozenset(tokens) not in allowed:
                drift.append((p, tokens))
    if drift:
        for p, tokens in drift:
            print(
                f"  [失败] {p.relative_to(root).as_posix()} 写死的角色清单不是三种合法清单之一"
                f"（实际 {sorted(tokens)}；允许：全部 {sorted(role_set)} / "
                f"软废弃 {sorted(soft_set)} / 部署 {sorted(deploy_set)}）"
            )
        ok = False
    else:
        print(
            f"  [通过] 脚本里的角色清单均可解释："
            f"全部 {len(role_set)} / 软废弃 {len(soft_set)} / 部署 {len(deploy_set)}"
        )

    # —— ③-补 三者必须构成划分（互补 + 不相交）—— 软废弃名单写错会立刻暴露
    if (soft_set | deploy_set) != role_set or (soft_set & deploy_set):
        print(
            "  [失败] SOFT_RETIRED / DEPLOY_ROLES / PORTS 不构成划分："
            f"并集多出 {sorted((soft_set | deploy_set) - role_set)}、"
            f"漏了 {sorted(role_set - (soft_set | deploy_set))}、"
            f"交集 {sorted(soft_set & deploy_set)}"
        )
        ok = False
    else:
        print(
            f"  [通过] PORTS == SOFT_RETIRED ⊎ DEPLOY_ROLES"
            f"（{len(soft_set)} + {len(deploy_set)} = {len(role_set)}）"
        )

    # —— ④ 每个角色一个单元，且启动的必须是它自己；错开延迟两两不同
    #       （延迟重复 = 两个进程同时登录 Registry，会互相顶掉会话）
    delays: list[int] = []
    for role in sorted(PORTS):
        unit = root / f"deploy/systemd/acps-{role}.service"
        if not unit.exists():
            print(f"  [失败] 缺少 systemd 单元 deploy/systemd/acps-{role}.service")
            ok = False
            continue
        body = unit.read_text(encoding="utf-8", errors="replace")
        if f"run_agent {role}" not in body:
            print(f"  [失败] {unit.name} 的 ExecStart 没有启动角色 {role}")
            ok = False
        m = re.search(r"^ExecStartPre=/bin/sleep\s+(\d+)", body, re.M)
        delays.append(int(m.group(1)) if m else 0)
    if len(set(delays)) != len(delays):
        print(f"  [失败] 单元启动延迟有重复：{sorted(delays)}（并发登录会互相顶掉会话）")
        ok = False
    else:
        print(f"  [通过] {len(delays)} 个单元的启动延迟两两不同：{sorted(delays)} 秒")

    # —— ⑤ 状态解释表必须与 wit 的真实枚举**逐字一致**
    #      `tools/status.py` 的 MEANING 是给人看的说明书。2026-09-30 审计发现：
    #      它只写了 6 个键，其中 `needs_agent_registration` 还是个**不存在的键**
    #      （死键，永不命中）；而真正要人介入的 blocked / rejected / failed
    #      全部落进兜底分支，提示还指向该脚本**根本没有**的 "summary" 段 ——
    #      等于对最需要处理的情况给了误导提示。
    #      枚举属于**外部事实**（来自 wit），只能比对，不能凭印象维护。
    try:
        import typing

        from wit.acps.provisioner import EnrollmentStatus
        from tools.status import MEANING as _STATUS_MEANING

        real_states = set(typing.get_args(EnrollmentStatus))
        missing = sorted(real_states - set(_STATUS_MEANING))
        dead = sorted(set(_STATUS_MEANING) - real_states)
        if missing or dead:
            if missing:
                print(
                    f"  [失败] tools/status.py 缺 {len(missing)} 个真实状态"
                    f"（这些会落进兜底、显示成「未知状态」）：{missing}"
                )
            if dead:
                print(f"  [失败] tools/status.py 有 {len(dead)} 个不存在的死键：{dead}")
            ok = False
        else:
            print(
                f"  [通过] 状态解释表与 wit 的 EnrollmentStatus 逐字一致"
                f"（{len(real_states)} 个状态全收录、无死键）"
            )

        # 光有"解释表"还不够：**分类**（要不要人工处理）也必须穷尽。
        # 否则 wit 新增一个状态时，它会静默落进"无需处理" —— 与死键同源的病：
        # 都是"外部事实变了，本地看板不吭声"。这里要求三张表合起来正好覆盖全集。
        from tools.status import (
            BENIGN_STATES as _BENIGN,
            SYNTHETIC_ERROR as _SYNTHETIC,
            TROUBLED_STATES as _TROUBLED,
        )

        universe = real_states | {_SYNTHETIC}
        union = _TROUBLED | _BENIGN
        unclassified = sorted(universe - union)
        unknown = sorted(union - universe)
        overlap = sorted(_TROUBLED & _BENIGN)
        problems: list[str] = []
        if unclassified:
            problems.append(f"有状态**未归类**（既不 troubled 也不 benign）：{unclassified}")
        if unknown:
            problems.append(f"归类表里有不存在的状态：{unknown}")
        if overlap:
            problems.append(f"同一状态被同时归为 troubled 与 benign：{overlap}")
        if _SYNTHETIC not in _TROUBLED:
            problems.append(
                f"{_SYNTHETIC}（本脚本合成的异常态）未列入 TROUBLED_STATES"
                " —— 出异常时不会出现在「需要人工处理」汇总里"
            )
        if problems:
            for p in problems:
                print(f"  [失败] 状态分类：{p}")
            ok = False
        else:
            print(
                f"  [通过] 状态分类穷尽且互斥：troubled {len(_TROUBLED)} 个"
                f"（含合成异常态 {_SYNTHETIC}）、benign {len(_BENIGN)} 个"
            )
    except Exception as exc:  # noqa: BLE001
        print(
            f"  [失败] 无法比对状态表（{type(exc).__name__}: {exc}）"
            " —— 要么 wit 的枚举位置变了，要么本机跑不到 tools 包"
        )
        ok = False

    # —— ⑥ 安全判据：Discovery 污染核对**不允许**静默给假的 ✅
    #      `tools/check_discovery_pollution.py` 的全部价值就是回答"污染还在不在"。
    #      早期它只判 `leaked` 为空就打印"无 demo 泄漏 ✅（清理生效）" ——
    #      于是**接口结构一变 / 所有查询都失败 / 全返回 0 条**时，它会把
    #      "什么都没查到"当成"确认没有污染"。这是安全结论里最危险的一类假阳性：
    #      清理没生效，它也说生效了（而本项目**唯一的清理判据**就是这个工具）。
    #      判据现已抽成纯函数 `verdict_of`，这里直接断言它的四种结局 ——
    #      **离线**守着"接口一变就再也不给假的 ✅"。
    try:
        from tools.check_discovery_pollution import RETIRED_AICS, verdict_of

        dead = next(iter(RETIRED_AICS))
        ok_aic = "1.2.156.3088.1.BUPT.81M3FX.COUJXB.F9XC6K.0J6D"  # 不在退役名单里的 AIC
        verdict_cases = [
            ("发现结果里出现已退役 demo → 报污染", {dead: "demo"}, [], 1, False),
            ("全部查询成功且有结果 → 确认无污染", {ok_aic: "正式"}, [], 0, True),
            ("有查询失败 → 无法判定，**不得**给 ✅", {ok_aic: "正式"}, ["事实核查"], 2, False),
            ("所有查询都空 → 无法判定，**不得**给 ✅", {}, [], 2, False),
        ]
        verdict_ok = True
        for label, seen_map, failed, want_code, want_tick in verdict_cases:
            # total_queries 只用于成功行的文案显示，探针里给个固定值即可。
            code, lines = verdict_of(seen_map, failed, 4)
            blob = "\n".join(lines)
            has_tick = "✅" in blob
            good = code == want_code and has_tick == want_tick
            if not good:
                ok = False
                verdict_ok = False
            print(
                f"  [{'通过' if good else '失败'}] 污染核对判据 · {label}："
                f"exit={code}（期望 {want_code}）、含✅={has_tick}（期望 {want_tick}）"
            )
        if verdict_ok:
            print(
                "  [通过] 污染核对：只在「全部查询成功且有结果」时才给 ✅，"
                "查不到一律「无法判定」"
            )
    except Exception as exc:  # noqa: BLE001
        print(
            f"  [失败] 无法加载 check_discovery_pollution.verdict_of（{type(exc).__name__}: {exc}）"
        )
        ok = False

    # —— ⑦ 验收看板不许有"永久假警报"
    #      2026-10-01 实测：`evidence-image`（8449）已定义但**尚未注册到平台**，
    #      于是 `systemd-install.sh verify` **每一次**都会报"有检查项未通过" ——
    #      三条判定全部命中（单元 not-found、开机自启 not-found、port_of 里没有它的端口）。
    #      永久红 == 真失败被淹没在里面，与 ③ 里那条"看板自己在骗人"是同一家族。
    #
    #      判据取"该角色**是否已注册**"（`.wit/<role>/acps/acs.final.json` 在不在）：
    #      平台只能调用已注册的角色 ⇒ "未注册 ⇒ 不该部署"是现场可推导的事实，
    #      不必再造一份"应部署清单"（那本身就是又一次"同一事实散在多处"）。
    #      这里**离线**钉住两件事：判据真的被用上、结论数量不再硬编码。
    board = root / "scripts/systemd-install.sh"
    try:
        board_text = board.read_text(encoding="utf-8", errors="replace")
        m = re.search(r"^do_verify\(\)\s*\{(.*?)^\}", board_text, re.M | re.S)
        verify_body = m.group(1) if m else ""
        if not verify_body:
            print(f"  [失败] 在 {board.name} 里找不到 do_verify() 函数体")
            ok = False
        else:
            board_problems: list[str] = []
            # 判据"被真的用上"要看 do_verify() 体内；判据"是什么"看全文
            # （`is_registered()` 定义在函数外，两者范围不同 —— 混成一个范围会
            #   出现"名字改了但判据没改"或"判据在但没用"都能蒙过去的假通过）。
            if "is_registered" not in verify_body:
                board_problems.append(
                    "do_verify() 没有调用注册判据 —— 未注册角色的「未部署」"
                    "会被当成失败，看板将**永远**显示未通过"
                )
            if "acs.final.json" not in board_text:
                board_problems.append(
                    "注册判据不是『存在 acs.final.json』—— 判据写错等于分流写错，"
                    "「未注册」与「单元被误删」会分不开"
                )
            if "${#ROLES[@]}" in verify_body:
                board_problems.append(
                    "do_verify() 结论行用 ${#ROLES[@]} 计数 —— 未部署的角色也会被算进"
                    "「N 个角色」，报出的数字大于实际检查过的"
                )
            if board_problems:
                for p in board_problems:
                    print(f"  [失败] 验收看板：{p}")
                ok = False
            else:
                print("  [通过] 验收看板：未注册角色的「未部署」不算失败，结论数量来自实测")
    except Exception as exc:  # noqa: BLE001
        print(f"  [失败] 无法检查验收看板（{type(exc).__name__}: {exc}）")
        ok = False

    if ok:
        print("\n  [通过] 启停链路卫生：脚本可直接部署，角色清单不会悄悄漂移")
    return ok


async def check_acs() -> bool:
    section("4. ACS 草稿生成（离线）")
    ok = True
    for role in BUILDERS:
        agent = BUILDERS[role](DUMMY_MODEL)
        runtime = WitRuntime(
            agent,
            workspace=f".wit/{role}",
            acps=build_config(role=role),
        )
        draft = runtime.acs_draft()
        path = runtime.save_acs()
        print(f"\n  [{role}] 草稿已保存 -> {path}")
        print(f"        protocolVersion={draft['protocolVersion']}  aic={draft['aic'] or '（注册后分配）'}")
        print(f"        active={draft['active']}  endPoints={draft['endPoints'] or '（未设置 public_endpoint）'}")
        for s in draft["skills"]:
            print(f"        skill: {s['id']}  in={s['inputModes']} out={s['outputModes']}")
        result = await runtime.validate()
        status = result.get("status") if isinstance(result, dict) else result
        print(f"        validate() -> {status if status is not None else '无问题'}")
        if isinstance(result, dict) and result.get("diagnostics"):
            print(f"        diagnostics: {result['diagnostics']}")
    return ok


def check_environment() -> None:
    section("5. 环境与凭据现状")
    print(describe("leader"))
    print()
    import os

    for key in ("ACPS_USERNAME", "ACPS_PASSWORD", "ACPS_PUBLIC_HOST", "ACPS_PUBLIC_ENDPOINT",
                "OPENAI_MODEL", "OPENAI_API_KEY", "OPENAI_BASE_URL"):
        value = os.environ.get(key)
        if key in ("ACPS_PASSWORD", "OPENAI_API_KEY"):
            shown = "已设置（已隐藏）" if value else "未设置"
        else:
            shown = value or "未设置"
        print(f"  {key:<22} = {shown}")


def main() -> None:
    load_env()  # 自动读项目根目录的 .env

    results = [
        ("数据契约", check_contracts()),
        ("Agent 编译", check_agents()),
        ("护栏（终止/熔断）", check_guards()),
        ("嵌套结构", check_nesting()),
        ("协议声明", check_protocols()),
        ("脚本卫生", check_scripts()),
    ]
    acs_ok = asyncio.run(check_acs())
    results.append(("ACS 草稿", acs_ok))
    check_environment()

    section("自检结论")
    for name, ok in results:
        print(f"  {'[通过]' if ok else '[失败]'}  {name}")
    failed = [n for n, ok in results if not ok]
    if failed:
        raise SystemExit(f"\n以下环节未通过：{', '.join(failed)}")
    print("\n  本地层面全部就绪。这一步之后，能否真正互联只取决于：")
    print("    1) .env 里的 ACPS_USERNAME / ACPS_PASSWORD 是否有效（已自助注册，见 ACCOUNT.txt）")
    print("    2) Partner 是否有一个公网可达的 public_endpoint（裸 IP 即可）")
    print("    3) 平台是否已人工审核通过（查：python -m tools.status）")
    print("  证书不用管：wit 在 enroll() 时会自动向平台 CA 申请签发。")


if __name__ == "__main__":
    main()
